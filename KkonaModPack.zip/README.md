# Sound mod for Lethal Company.
## This mod replaces some sounds in Lethal.


### Version 1.0.0
* Initial version of modpack.

### Version 1.0.1
* Added new creature sounds.